package test;

import static org.junit.jupiter.api.Assertions.*;

import main.Queue;
import org.junit.jupiter.api.Test;

import java.util.NoSuchElementException;
/**
 * This class tests queue class
 *
 * @author Yixing Tang
 * <yixingtang@brandeis.edu>
 * <Oct 7, 2022>
 * COSI 21A PA1
 */
class StudentQueueTest {


    @Test
    void testEnqueue() {
        Queue<Integer> q = new Queue<>(5);
        q.enqueue(1);
        assertEquals(1, q.size());
        q.enqueue(2);
        assertEquals(2, q.tail);
        q.enqueue(3);
        q.enqueue(4);
        assertEquals(4, q.numEntries);
        q.enqueue(5);
        assertEquals(0, q.head);
        assertEquals(5, q.size());
    }

    @Test
    void testExpand() {
        Queue<Integer> q = new Queue<>(2);
        q.enqueue(1);
        assertEquals(1, q.size());
        q.enqueue(2);
        assertEquals(2, q.tail);
        q.enqueue(3);
        q.enqueue(4);
        assertEquals(4, q.numEntries);
        q.enqueue(5);
        assertEquals(0, q.head);
        assertEquals(5, q.size());
    }

    @Test
    void testDequeue() {
        Queue<Integer> q = new Queue<>(10);
        q.enqueue(1);
        q.enqueue(2);
        q.enqueue(3);
        q.enqueue(4);
        q.enqueue(5);
        assertEquals(1, q.front());
        q.dequeue();
        assertEquals(2, q.front());
        q.dequeue();
        assertEquals(3, q.front());
        q.dequeue();
        assertEquals(4, q.front());
        q.dequeue();
        assertEquals(5, q.front());
        try{
            q.front();
        }catch (Exception e){
            assertTrue(e instanceof NoSuchElementException);
        }
        try{
            q.dequeue();
        }catch (Exception e){
            assertTrue(e instanceof NoSuchElementException);
        }
    }
}
