package test;

import static org.junit.jupiter.api.Assertions.*;

import main.DoubleLinkedList;
import org.junit.jupiter.api.Test;
/**
 * This class test doublelinkedlist class
 *
 * @author Yixing Tang
 * <yixingtang@brandeis.edu>
 * <Oct 7, 2022>
 * COSI 21A PA1
 */
class StudentDLLTest {

    @Test
    void testGetFirst() {
        DoubleLinkedList<Integer> l = new DoubleLinkedList<>();
        l.insert(1);
        l.insert(2);
        l.insert(3);
        l.insert(4);
        l.insert(5);
        assertEquals(1, l.getFirst().getData());
    }

    @Test
    void testInsert() {
        DoubleLinkedList<Integer> l = new DoubleLinkedList<>();
        l.insert(1);
        l.insert(2);
        l.insert(3);
        l.insert(4);
        l.insert(5);
        assertEquals(5, l.size());
        l.delete(4);
        assertEquals(4, l.size());
        l.delete(2);
        assertEquals(3, l.size());
        l.delete(1);
        assertEquals(2, l.size());

        assertEquals(3, l.getFirst().getData());
    }

    @Test
    void testDelete() {
        DoubleLinkedList<Integer> l = new DoubleLinkedList<>();
        l.insert(1);
        l.insert(2);
        l.insert(3);
        l.insert(4);
        l.insert(5);
        assertEquals(5, l.size());
        Integer d = l.delete(6);
        assertNull(d);
        d = l.delete(5);
        assertEquals(5, d);
        d = l.delete(3);

        assertEquals(3, d);
        assertEquals(3, l.size());


    }
}
