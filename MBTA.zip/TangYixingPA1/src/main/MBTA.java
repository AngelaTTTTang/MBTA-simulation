package main;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * This class provides the implementation of a generic non-circular doubly linked list.
 * Known Bugs: None
 *
 * @author Yixing Tang
 * <yixingtang@brandeis.edu>
 * <Oct 7, 2022>
 * COSI 21A PA1
 */
public class MBTA {

    public static final int SOUTHBOUND = 1;
    public static final int NORTHBOUND = 0;

    static final int TIMES = 6;
    static Railway r;
    /**
     * construct the Railway with Stations, Riders, and Trains and run the simulation
     * running time: O(n)
     * @param args loaded from the provided text files
     */
    public static void main(String[] args) {
        r = new Railway();
        initStations("redLine.txt");
        initTrains("trains.txt");
        initRiders("riders.txt");
        System.out.println("INITIATED RED LINE");
        System.out.println();
        for (String stationName : r.stationNames){
            Station s  = r.railway.get(new Station(stationName));
            System.out.println(s.toString());
        }
        System.out.println("BEGINNING RED LINE SIMULATION");
        runSimulation();
    }
    /**
     * simulation using TIMES and Railway’s simulate()
     * running time: O(n)
     */
    public static void runSimulation() {
        System.out.println();
        for (int i = 0; i < TIMES; i++) {
            System.out.println("-------Round " + (i + 1)+ "-------\n");
            String log = r.simulate();
            System.out.println(log);
        }
    }
    /**
     * constructs Trains from an input file and adds them to the Railway
     * running time: O(n)
     * @param trainsFile loaded from the provided text files
     */
    public static void initTrains(String trainsFile) {
        try {
            Scanner sc = new Scanner(new File(trainsFile));
            while (sc.hasNextLine()) {
                String startStation = sc.nextLine();
                int direction = Integer.parseInt(sc.nextLine());
                r.addTrain(new Train(startStation, direction));
            }
            sc.close();
        } catch (FileNotFoundException e) {

        }

    }
    /**
     * constructs Riders from an input file and adds them to the Railway
     * running time: O(n)
     * @param ridersFile from an input file
     */
    public static void initRiders(String ridersFile) {
        try {
            Scanner sc = new Scanner(new File(ridersFile));
            while (sc.hasNextLine()) {
                String riderId = sc.nextLine();
                String start = sc.nextLine();
                String end = sc.nextLine();
                r.addRider(new Rider(riderId, start, end));
            }
            sc.close();
        } catch (FileNotFoundException e) {

        }
    }
    /**
     * constructs Stations from an input file and adds them to the Railway
     * running time: O(n)
     * @param stationsFile from an input file
     */
    public static void initStations(String stationsFile) {
        try {
            Scanner sc = new Scanner(new File(stationsFile));
            while (sc.hasNextLine()) {
                String s = sc.nextLine();
                r.addStation(new Station(s));
            }
            sc.close();
        } catch (FileNotFoundException e) {

        }
    }
}
