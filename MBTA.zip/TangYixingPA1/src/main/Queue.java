package main;

import java.util.NoSuchElementException;

/**
 * This class provides the implementation of a generic non-circular doubly linked list.
 * Known Bugs: None
 *
 * @author Yixing Tang
 * <yixingtang@brandeis.edu>
 * <Oct 7, 2022>
 * COSI 21A PA1
 */
public class Queue<T> {

    public T[] q;
    public int head;
    public int tail;
    public int numEntries;

    @SuppressWarnings("unchecked")
    /**
     * constructs an empty queue
     * running time: O(1)
     * @param capacity size of the queue
     */
    public Queue(int capacity) {
        this.q = (T[]) new Object[capacity];
        this.head = 0;
        this.tail = 0;
        this.numEntries = 0;

    }
    /**
     * adds an element at the tail of the queue
     * running time: O(n)
     * @param element at the tail of the queue
     */
    public void enqueue(T element) {
        q[tail] = element;
        tail = (tail + 1 + q.length) % q.length;
        numEntries++;
        if (this.q.length <= numEntries) {
            expand();
        }
    }
    /**
     * expand the queue
     * running time: O(n)
     */
    private void expand() {
        T[] temp = (T[]) new Object[this.q.length * 2];
        for (int i = 0; i < this.q.length; i++) {
            int index = (head + i) % this.q.length;
            temp[i] = q[index];
        }
        head = 0;
        tail = this.q.length;
        this.q = temp;
    }
    /**
     * removes the element at the head of the queue
     * running time: O(1)
     */
    public void dequeue() {
        if (numEntries == 0) {
            throw new NoSuchElementException();
        }
        q[head] = null;
        head = (head + 1 + this.q.length) % this.q.length;
        numEntries--;
    }
    /**
     * returns the element at the head of the queue
     * running time: O(1)
     * @return element at the head
     */
    public T front() {
        if (numEntries == 0) {
            throw new NoSuchElementException();
        }
        return q[head];
    }
    /**
     * return the number of elements in the queue
     * running time: O(1)
     * @return the number of elements
     */
    public int size() {
        return numEntries;
    }
    
    @Override
    /**
     * return a String representation of the queue’s elements
     * running time: O(n)
     */
    public String toString() {
        String res = "";
        for (int i = 0; i < numEntries; i++) {
            int index = (head + i) % this.q.length;
            res += q[index].toString() + ",";
        }
        return res;
    }
}
