package main;
/**
 * This class provides the implementation of a generic non-circular doubly linked list.
 * Known Bugs: None
 *
 * @author Yixing Tang
 * <yixingtang@brandeis.edu>
 * <Oct 7, 2022>
 * COSI 21A PA1
 */
public class DoubleLinkedList<T> {

    private Node<T> head;
    private Node<T> tail;
    private int size;

    /**
     * Construct Method
     * running time: O(1)
     * initializes a doubly linked list to have 0 elements.
     */
    public DoubleLinkedList() {
        head = new Node<>(null);
        tail = new Node<>(null);
        head.setNext(tail);
        tail.setPrev(head);
        size = 0;
    }

    /**
     * gets the first node in the list or null if one does not exist.
     * running time: O(1)
     * @return the first element, if the list is empty return null.
     */
    public Node<T> getFirst() {
        return head.getNext() == tail ? null : head.getNext();
    }


    /**
     * adds an element to the end of this list.
     * running time: O(1)
     * @param element the data to be inserted
     */
    public void insert(T element) {
        Node<T> n = new Node<>(element);
        Node<T> prev = tail.getPrev();
        prev.setNext(n);
        n.setPrev(prev);
        n.setNext(tail);
        tail.setPrev(n);
        size++;
    }

    /**
     * deletes the first element from this list that matches the provided key. If the provided key does not exist in the list, return null.
     * running time: O(n)
     * @param key the element to be deleted
     * @return the first element in the list that matches the provided key or null if one cannot be found.
     */
    public T delete(T key) {
        Node<T> n = head.getNext();
        while (n != tail) {
            if (n.getData().equals(key)) {
                T res = n.getData();
                n.getPrev().setNext(n.getNext());
                n.getNext().setPrev(n.getPrev());
                size--;
                return res;
            }
            n = n.getNext();
        }
        return null;
    }

    /**
     * returns the first element in the list that matches the provided key or null if one cannot be found.
     * running time: O(n)
     * @param key key the element to be deleted
     * @returnthe first element in the list that matches the provided key or null if one cannot be found.
     */
    public T get(T key) {
        Node<T> n = head.getNext();
        while (n != tail) {
            if (n.getData().equals(key)) {
                return n.getData();
            }
            n = n.getNext();
        }
        return null;
    }

    /**
     * returns the number of elements in the list.
     * running time: O(1)
     * @return the number of elements in the list.
     */
    public int size() {
        return size;
    }

    /**
     * returns a String representation of this list’s elements.
     * running time: O(n)
     * @return a String representation of this list’s elements.
     */
    @Override
    public String toString() {
        Node<T> n = head.getNext();
        String res = "";
        while (n != tail) {
            res += n.getData().toString();
            n = n.getNext();
        }
        return res;
    }
}
