package main;

import java.util.NoSuchElementException;

/**
 * This class provides the implementation of a generic non-circular doubly linked list.
 * Known Bugs: None
 *
 * @author Yixing Tang
 * <yixingtang@brandeis.edu>
 * <Oct 7, 2022>
 * COSI 21A PA1
 */
public class Station {

    public Queue<Rider> northBoundRiders;
    public Queue<Rider> southBoundRiders;
    public Queue<Train> northBoundTrains;
    public Queue<Train> southBoundTrains;
    private String name;
    private final int default_size = 100;
    /**
     * constructs an empty Station
     * running time: O(1)
     * @param name: given name
     */
    public Station(String name) {
        this.name = name;
        this.northBoundRiders = new Queue<>(default_size);
        this.southBoundRiders = new Queue<>(default_size);
        this.northBoundTrains = new Queue<>(default_size);
        this.southBoundTrains = new Queue<>(default_size);
    }
    /**
     * adds a Rider to the appropriate Queue
     * running time: O(n)
     * @param r: Rider
     * @return: Return true if this is possible and false otherwise.
     */
    public boolean addRider(Rider r) {
        if (r.getStarting().equals(this.name)) {
            if (r.goingNorth()) {
                northBoundRiders.enqueue(r);
            } else {
                southBoundRiders.enqueue(r);
            }
        }
        return false;
    }
    /**
     * moves a Train into this Station
     * running time: O(n)
     * @param t: Train
     * @return a String that includes that some passengers
     */
    public String addTrain(Train t) {
        t.updateStation(name);
        String disembarkPassengers = t.disembarkPassengers();
        if (t.goingNorth()) {
            northBoundTrains.enqueue(t);
        } else {
            southBoundTrains.enqueue(t);
        }
        return name + " Disembarking Passengers:\n"
                + disembarkPassengers
                + "Direction: " + (t.goingNorth() ? "Northbound" : "Southbound") + "\n"
                + "Passengers:\n" + t.currentPassengers()
                + "Current station: " + stationName() + "\n";
    }
    /**
     * prepare a southbound Train of passengers
     * running time: O(n)
     * @return: the train that has been filled or null
     */
    public Train southBoardTrain() {
        try {
            Train t = southBoundTrains.front();
            southBoundTrains.dequeue();
            while (southBoundRiders.size() != 0 && t.addPassenger(southBoundRiders.front())) {
                southBoundRiders.dequeue();
            }
            return t;
        } catch (NoSuchElementException e) {
            return null;
        }
    }
    /**
     * prepare a northbound Train of passengers
     * running time: O(n)
     * @return: the train that has been filled or null
     */
    public Train northBoardTrain() {
        try {
            Train t = northBoundTrains.front();
            northBoundTrains.dequeue();
            while (northBoundRiders.size() != 0 && t.addPassenger(northBoundRiders.front())) {
                northBoundRiders.dequeue();
            }
            return t;
        } catch (NoSuchElementException e) {
            return null;
        }
    }
    /**
     * changes the direction of the first waiting northbound Train
     * running time: O(1)
     */
    public void moveTrainNorthToSouth() {
        Train t = northBoundTrains.front();
        northBoundTrains.dequeue();
        t.swapDirection();
        southBoundTrains.enqueue(t);

    }
    /**
     * changes the direction of the first waiting southbound Train
     * running time: O(1)
     */
    public void moveTrainSouthToNorth() {
        Train t = southBoundTrains.front();
        southBoundTrains.dequeue();
        t.swapDirection();
        northBoundTrains.enqueue(t);
    }
    /**
     * return the name and status of the station
     * running time: O(1)
     */
    @Override
    public String toString() {
        return String.format("Station: %s\n" +
                        "%d north-bound trains waiting\n" +
                        "%d south-bound trains waiting\n" +
                        "%d north-bound passengers waiting\n" +
                        "%d south-bound passengers waiting\n", name, northBoundTrains.size(),
                southBoundTrains.size()
                , northBoundRiders.size(), southBoundRiders.size());
    }
    /**
     * returns the name of this Station
     * running time: O(1)
     * @return name of this Station
     */
    public String stationName() {
        return name;
    }
    /**
     * Checks if a Station is equal
     * running time: O(1)
     */
    @Override
    public boolean equals(Object o) {
        if (o instanceof Station) {
            return ((Station) o).name.equals(this.name);
        }
        return false;
    }
}
