package main;

import java.util.NoSuchElementException;

/**
 * This class provides the implementation of a generic non-circular doubly linked list.
 * Known Bugs: None
 *
 * @author Yixing Tang
 * <yixingtang@brandeis.edu>
 * <Oct 7, 2022>
 * COSI 21A PA1
 */
public class Railway {

    public DoubleLinkedList<Station> railway;
    public String[] stationNames;
    
    /**
     * constructs an empty Railway
     * running time: O(1)
     */
    public Railway() {
        railway = new DoubleLinkedList<>();
        stationNames = new String[18];
    }
    /**
     * adds a Station to the Railway
     * running time: O(n)
     * @param s : Station
     */
    public void addStation(Station s) {
        railway.insert(s);
        for (int i = 0; i < stationNames.length; i++) {
            if (stationNames[i] == null) {
                stationNames[i] = s.stationName();
                return;
            }
        }
    }
    /**
     * sets a Rider’s direction & adds the Rider to the appropriate Station
     * running time: O(1)
     * @param r : Rider
     */
    public void addRider(Rider r) {
        setRiderDirection(r);
        Station s = railway.get(new Station(r.getStarting()));
        s.addRider(r);
    }
    /**
     * adds a Train to the appropriate Station
     * running time: O(1)
     * @param t: Train
     */
    public void addTrain(Train t) {
        Station s = railway.get(new Station(t.getStation()));
        s.addTrain(t);
    }
    /**
     * sets a Rider’s direction based
     * running time: O(n)
     * @param r : Rider
     */
    public void setRiderDirection(Rider r) {
        int startIndex = -1;
        int endIndex = -1;
        for (int i = 0; i < stationNames.length; i++) {
            if (r.getStarting().equals(stationNames[i])) {
                startIndex = i;
            }
            if (r.getDestination().equals(stationNames[i])) {
                endIndex = i;
            }
        }
        boolean isNorth = startIndex > endIndex;
        if (r.goingNorth() != isNorth) {
            r.swapDirection();
        }
    }
    /**
     * execute one simulation of the Railway
     * running time: O(n)
     * @return log
     */
    public String simulate() {
        String log = "";
        for (int i = 0; i < stationNames.length; i++) {
            Station s = railway.get(new Station(stationNames[i]));
            Station southNextStation = railway.get(new Station(stationNames[(i + 1 + stationNames.length) % stationNames.length]));
            Station northNextStation = railway.get(new Station(stationNames[(i - 1 + stationNames.length) % stationNames.length]));
            log += s.toString() + "\n";
            if (!s.stationName().equals("Alewife")) {
                Train t = s.northBoardTrain();
                if (t != null) {
//                    log += String.format("move Train from %s to %s\n", s.stationName(), northNextStation.stationName());
                    t.updateStation(northNextStation.stationName());
                    String addTrainLog = northNextStation.addTrain(t);
                    log += addTrainLog + "\n";
                }
            }
            if (!s.stationName().equals("Braintree")) {
                Train t = s.southBoardTrain();
                if (t != null) {
//                    log += String.format("move Train from %s to %s\n", s.stationName(), southNextStation.stationName());
                    t.updateStation(southNextStation.stationName());
                    String addTrainLog = southNextStation.addTrain(t);
                    log += addTrainLog + "\n";
                }

            }

            if (s.stationName().equals("Braintree")) {
                try {
                    s.moveTrainSouthToNorth();
//                    log += "Current Station is " + s.stationName() + " move one south train to north \n";
                } catch (NoSuchElementException e) {

                }
            }
            if (s.stationName().equals("Alewife")) {
                try {
                    s.moveTrainNorthToSouth();
//                    log += "Current Station is " + s.stationName() + " move one north train to south \n";
                } catch (NoSuchElementException e) {

                }
            }
        }
        return log;
    }
    
    /**
     * returns the Stations list’s String representation
     * running time: O(1)
     */
    @Override
    public String toString() {
        return String.join(",", stationNames);
    }
}
