package main;

/**
 * This class provides the implementation of a generic non-circular doubly linked list.
 * Known Bugs: None
 *
 * @author Yixing Tang
 * <yixingtang@brandeis.edu>
 * <Oct 7, 2022>
 * COSI 21A PA1
 */
public class Rider {
    private String riderId;
    private String startingStation;
    private String destinationStation;
    private int direction;

    /**
     * Construct method
     * running time: O(1)
     * @param riderID
     * @param startingStation
     * @param destinationStation
     */
    public Rider(String riderID, String startingStation, String destinationStation) {
        this.riderId = riderID;
        this.startingStation = startingStation;
        this.destinationStation = destinationStation;
        this.direction = MBTA.SOUTHBOUND;
    }

    /**
     * returns the name of this Rider’s starting station.
     * running time: O(1)
     * @return the name of this Rider’s starting station.
     */
    public String getStarting() {
        return startingStation;
    }

    /**
     * returns the name of this Rider’s ending station.
     * running time: O(1)
     * @return   the name of this Rider’s ending station.
     */
    public String getDestination() {
        return destinationStation;
    }

    /**
     * returns this Rider’s ID.
     * running time: O(1)
     * @return this Rider’s ID.
     */
    public String getRiderID() {
        return riderId;
    }

    /**
     * returns true if this Rider is northbound. Else, false.
     * running time: O(1)
     * @return true if this Rider is northbound. Else, false.
     */
    public boolean goingNorth() {
        return this.direction == MBTA.NORTHBOUND;
    }

    /**
     * swaps the Rider’s current direction.
     * running time: O(1)
     */
    public void swapDirection() {
        this.direction = this.direction == MBTA.NORTHBOUND
                ? MBTA.SOUTHBOUND : MBTA.NORTHBOUND;
    }

    @Override
    /**
     * returns a String representation of this Rider.
     * running time: O(1)
     */
    public String toString() {
        return "RiderId:" + riderId + ",start:" + startingStation + ",end:" + destinationStation + ", north:" + goingNorth();
    }
    
    /**
     * checks if this Rider is equal to another Object
     * running time: O(1)
     */
    @Override
    public boolean equals(Object s) {
        if (s instanceof Rider) {
            return ((Rider) s).riderId.equals(this.riderId);
        }
        return false;
    }
}
