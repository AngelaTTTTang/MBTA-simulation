package main;

/**
 * This class provides the implementation of a generic non-circular doubly linked list.
 * Known Bugs: None
 *
 * @author Yixing Tang
 * <yixingtang@brandeis.edu>
 * <Oct 7, 2022>
 * COSI 21A PA1
 */
public class Train {

    public static final int TOTAL_PASSENGERS = 10;
    public Rider[] passengers;
    public int passengerIndex;
    private String currentStation;
    //south (1) or north (0).
    private int direction;
    /**
     * constructs an empty Train at a given Station
     * running time: O(1)
     * @param currentStation given Station
     * @param direction either south (1) or north (0)
     */
    public Train(String currentStation, int direction) {
        this.passengers = new Rider[TOTAL_PASSENGERS];
        this.currentStation = currentStation;
        this.direction = direction;
        this.passengerIndex = 0;
    }
    /**
     * returns true if this Train is northbound
     * running time: O(1)
     * @return
     */
    public boolean goingNorth() {
        return direction == MBTA.NORTHBOUND;
    }
    /**
     * swaps the Train’s direction
     * running time: O(1)
     */
    public void swapDirection() {
        this.direction = this.direction == MBTA.NORTHBOUND ? MBTA.SOUTHBOUND : MBTA.NORTHBOUND;
    }
    /**
     * returns a String of the current passengers
     * running time: O(n)
     * @return returns a String of passengers
     */
    public String currentPassengers() {
        String res = "";
        for (int i = 0; i < passengerIndex && i < passengers.length; i++) {
            res += passengers[i].getRiderID() + ", " + passengers[i].getDestination() + "\n";
        }
        return res;
    }
    /**
     * adds a passenger to the Train
     * running time: O(1)
     * @param r rider
     * @return if the addition was completed
     */
    public boolean addPassenger(Rider r) {
        if (r.getStarting().equals(this.currentStation)
                && r.goingNorth() == this.goingNorth()
                && hasSpaceForPassengers()) {
            passengers[passengerIndex] = r;
            passengerIndex++;
            return true;
        }
        return false;
    }
    /**
     * returns true if the Train has space
     * running time: O(1)
     * @return returns true if the Train has space
     */
    public boolean hasSpaceForPassengers() {
        return passengerIndex < TOTAL_PASSENGERS;
    }
    /**
     * remove all of the passengers
     * running time: O(n^2)
     * @return a String of the removed passengers
     */
    public String disembarkPassengers() {
        String res = "";
        for (int i = 0; i < passengerIndex; i++) {
            Rider r = passengers[i];
            if (r.getDestination().equals(this.currentStation)) {
                res += r.getRiderID() + "\n";
                for (int j = i; j < TOTAL_PASSENGERS - 1; j++) {
                    passengers[j] = passengers[j + 1];
                }
                passengerIndex--;
            }
        }
        return res;
    }
    /**
     * Updates the name of this Train’s current station
     * running time: O(1)
     * @param s station
     */
    public void updateStation(String s) {
        this.currentStation = s;
    }
    /**
     * returns the name of the Train’s current Station
     * running time: O(1)
     * @return name of current Station
     */
    public String getStation() {
        return currentStation;
    }
    /**
     * returns a String representation of this Train
     * running time: O(n)
     */
    @Override
    public String toString() {
        String passengserStr = "";
        for (int i = 0; i < passengerIndex; i++) {
            passengserStr += passengers[i].toString() + "\n";
        }
        return "Train{" +
                "passengers=" + passengserStr +
                ", passengerIndex=" + passengerIndex +
                ", currentStation='" + currentStation + '\'' +
                ", direction=" + direction +
                '}';
    }
}
