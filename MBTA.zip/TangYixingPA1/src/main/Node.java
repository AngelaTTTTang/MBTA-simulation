package main;
/**
 * This class provides the implementation of a generic non-circular doubly linked list.
 * Known Bugs: None
 *
 * @author Yixing Tang
 * <yixingtang@brandeis.edu>
 * <Oct 7, 2022>
 * COSI 21A PA1
 */
public class Node<T> {
    private T data;
    private Node<T> prev;
    private Node<T> next;
    /**
     * constructs a doubly linked list node that holds 
     * running time: O(1)
     * @param data a field but does not point to any other nodes
     */
    public Node(T data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
    /**
     * sets the data field of this node
     * running time: O(1)
     * @param data
     */
    public void setData(T data) {
        this.data = data;
    }
    /**
     * sets the next pointer of this node
     * running time: O(1)
     * @param next pointer of this node
     */
    public void setNext(Node<T> next) {
        this.next = next;
    }
    /**
     * sets the previous pointer of this node
     * running time: O(1)
     */
    public void setPrev(Node<T> prev) {
        this.prev = prev;
    }
    /**
     * returns the pointer to the next node or null
     * running time: O(1)
     * @return the pointer to the next node
     */
    public Node<T> getNext() {
        return this.next;
    }
    /**
     * returns the pointer to the previous node or null
     * running time: O(1)
     * @return the pointer to the previous node
     */
    public Node<T> getPrev() {
        return this.prev;
    }
    
    /**
     * returns the data stored in this node
     * running time: O(1)
     * @return data stored
     */
    public T getData() {
        return this.data;
    }
    
    /**
     * returns the String representation of this node’s element
     * running time: O(1)
     */
    @Override
    public String toString() {
        return data == null ? "null" : data.toString();
    }
}
